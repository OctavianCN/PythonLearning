# module1.py

print(f'loading run.py: __name__ = {__name__}')